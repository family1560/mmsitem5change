package kr.co.item.command;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.item.dao.ItemDAO;
import kr.co.item.domain.CommandAction;
import kr.co.item.domain.ItemDTO;

public class ListCommand implements Command {

	@Override
	public CommandAction execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		ItemDAO dao = new ItemDAO();
		List<ItemDTO> list = dao.list();
		
		request.setAttribute("list", list);
		
		return new CommandAction("jsp/item/list.jsp", false) ;
	}

}
