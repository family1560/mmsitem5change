package kr.co.item.command;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.item.dao.ItemDAO;
import kr.co.item.domain.CommandAction;
import kr.co.item.domain.ItemDTO;

public class UpdateCommand implements Command {

	@Override
	public CommandAction execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String item = request.getParameter("item");
		
		String sPrice = request.getParameter("price");
		int price = Integer.parseInt(sPrice);
		
		String sDis = request.getParameter("dis");
		double dis = Double.parseDouble(sDis);
		
		ItemDAO dao = new ItemDAO();
		dao.update(new ItemDTO(item, price, dis));
		
		
		return new CommandAction("list.do", true);
	}

}
