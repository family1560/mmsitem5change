package kr.co.item.command;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.item.dao.ItemDAO;
import kr.co.item.domain.CommandAction;
import kr.co.item.domain.ItemDTO;

public class DeleteUICommand implements Command {

	@Override
	public CommandAction execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String item = request.getParameter("item");
		
		request.setAttribute("item", item);
		
		return new CommandAction("jsp/item/delete.jsp", false);
	}

}
