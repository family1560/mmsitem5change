package kr.co.item.domain;

import java.io.Serializable;
import java.util.Objects;

public class ItemDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String item;	//품목이름
	private int price;		//단가
	private double dis;		//할인율
	
	public ItemDTO() {
		// TODO Auto-generated constructor stub
	}

	public ItemDTO(String item, int price, double dis) {
		super();
		this.item = item;
		this.price = price;
		this.dis = dis;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public double getDis() {
		return dis;
	}

	public void setDis(double dis) {
		this.dis = dis;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(item);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemDTO other = (ItemDTO) obj;
		return Objects.equals(item, other.item);
	}

	@Override
	public String toString() {
		return "ItemDTO [item=" + item + ", price=" + price + ", dis=" + dis + "]";
	}
	
	

}
